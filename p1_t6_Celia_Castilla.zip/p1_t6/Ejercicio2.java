package p1_t6;
import java.io.*;
public class Ejercicio2 {
	public static void main(String[] args) throws IOException  {
		// TODO Auto-generated method stub
		FileWriter fichero =null;
		FileReader fichr= null;
		//Almacenamos la ruta del nombre del fichero
		String nombreF = "C:/Users/ccast/Desktop/Text1.txt";
		try {
			fichero =new FileWriter (nombreF);
			String linea = "Key Ideas\r\n" + 
					"� The credit market matches borrowers (the source of credit demand) and savers (the source of credit supply). � The credit market equilibrium determines the real interest rate";
			for ( int i = 0; i< linea.length(); i++) {
				fichero.write(linea.charAt(i));
			}
		//Cerramos el stream de datos
		fichero.close();	
			try {
				fichr= new FileReader (nombreF);
				int lectura = fichr.read();
				//recorremos el fichero hasta que encuentre el caracter -1
				while (lectura != -1) {
				System.out.print((char) lectura); // convertimos a char y lo mostramos por pantalla 
				lectura = fichr.read ();	
				}
		//Cerramos el flujo de datos
		fichr.close();
		}catch (FileNotFoundException e) {
			System.out.println ("Error: Fichero no encontrado");
			System.out.println (e.getMessage());
		}
				
		}catch (Exception e) {
			//Imprime toda la pila de excepciones
			e.printStackTrace();
		}	
	}
}


	
	
	
				

	
	
				
	
	
			
		

