package p1_t6;
import java.io.*;
public class Ejercicio3 {
	public static void main(String[] args) {
	int counter=0;
	//Almacenamos todos los bytes del array
	int datos_entrada[]=new int[53248];
	try {
		//Creamos la instancia por lo que ya tenemos un flujo de datos abierto
		//La imagen est� guardada con el formato jpg.jpg por defecto
		FileInputStream file_reading=new FileInputStream("C:/Users/ccast/Desktop/ficheroimagen/imagen.jpg");
		boolean final_file=false;
		while(!final_file) {
			int byte_entrance=file_reading.read();
			if(byte_entrance!=-1) {
				datos_entrada[counter]=byte_entrance;
				//Imprimimos los bytes que va leyendo 
				System.out.println(datos_entrada[counter]);
				counter++;
			}
			else {
				final_file=true;
			}
			
			
		}
	//cerramos el flujo de datos
	file_reading.close();
	}
	catch(IOException e) {
		System.out.println(" Error al acceder a la imagen,no se encuentra la imagen");
	}
	System.out.println(counter);
	create_file(datos_entrada);
}
	static void create_file(int datos_nuevo_fichero[]) {
		try {
			FileOutputStream fichero_nuevo=new FileOutputStream("C:/Users/ccast/Desktop/ficheroimagen/imagen_copia.jpg");
			for(int i=0;i<datos_nuevo_fichero.length;i++){
				fichero_nuevo.write(datos_nuevo_fichero[i]);	
			}
			//Cerramos el stream
			fichero_nuevo.close();
		}catch(IOException e){
			System.out.println("Error al crear el archivo");
			
		}
	}
}
