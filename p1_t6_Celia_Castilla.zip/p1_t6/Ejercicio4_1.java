package p1_t6;
import java.io.*;

import java.io.FileReader;


public class Ejercicio4_1 {
	public static void main(String[] args) {
				String nombreF = "C:/Users/ccast/Desktop/ficheroNuevo.txt";
				FileReader fich= null;
				BufferedReader BR = null;
				try {
					fich = new FileReader (nombreF);
					BR = new BufferedReader (fich);
					String linea;
					linea = BR.readLine();
					while (linea != null) {
						System.out.print(linea); 
						linea =BR.readLine();
						
					}
					//Cerramis el flujo de datos
					fich.close();
				}catch (IOException e) {
					System.out.println ("Error: Fichero no encontrado");
					System.out.println (e.getMessage());
				}
				
				
			
			
			}
			
	}
