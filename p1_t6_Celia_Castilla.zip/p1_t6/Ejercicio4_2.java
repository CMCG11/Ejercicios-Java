package p1_t6;
import java.io.*;
import java.io.FileWriter;
import java.io.IOException;
public class Ejercicio4_2 {
	public static void main(String[] args) throws IOException {
		
		FileWriter fichero =null;
		
		//Almacenamos la ruta del nombre del fichero
		String nombreF = "C:/Users/ccast/Desktop/Text1.txt";
		try {
			fichero =new FileWriter (nombreF);
			BufferedWriter mibuffer=new BufferedWriter(fichero);
			//String linea = "Key Ideas\r\n" + 
					//"� The credit market matches borrowers (the source of credit demand) and savers (the source of credit supply). � The credit market equilibrium determines the real interest rate";
			for ( int i = 0; i< 10; i++) {
				mibuffer.write("Key Ideas\\r\\n"+"� The credit market matches borrowers (the source of credit demand) and savers (the source of credit supply). � The credit market equilibrium determines the real interest rate"+i);
				mibuffer.newLine();
			}
			mibuffer.flush();
		//Cerramos el stream de datos
		fichero.close();
		//Este c�digo est� comentado puesto que no es v�lido a la hora de usar el buffer
			/*try {
				fichr= new FileReader (nombreF);
				int lectura = fichr.read();
				//recorremos el fichero hasta que encuentre el caracter -1
				while (lectura != -1) {
				System.out.print((char) lectura); // convertimos a char y lo mostramos por pantalla 
				lectura = fichr.read ();	
				}
		//Cerramos el flujo de datos
		fichr.close();
		}catch (FileNotFoundException e) {
			System.out.println ("Error: Fichero no encontrado");
			System.out.println (e.getMessage());
		}*/
				
		}catch (Exception e) {
			//Imprime toda la pila de excepciones
			e.printStackTrace();
		}	
	}
}

