package p1_t6;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
//Ejercicio1
public class EscribirFichero {
public static void main(String[] args) {
	//Instancia de escribir fichero
	 Escribiendo x = new Escribiendo();
	 //Llamamos al m�todo
	 x.escribir();
	 //Instancia de leer fichero
	 Leer_Fichero acceso=new Leer_Fichero();
	 //Llamamos al m�todo
	 acceso.lee();
	 //Instancia de contar vocales en un fichero 
	 contarVocales c=new contarVocales();
	 //LLamada al metodo de contar vocales 
	 c.countVoc();
	    }
	}
//We create a class that implements a method that writes the content of the file
class Escribiendo {
	public void escribir() {
	    String frase = "Por volver a pasear sin rumbo bajo el cielo de Madrid y reunirme con amigos y familia aunque no haya plan, que sea simplemente por vernos las caras sin una pantalla de por medio. \r\n" + 
	    		"�Y t�? �qu� sue�os tienes? #Buscatuestrella";
	    try {
	    	//Utilizamos una instancia pertenceiente a la clase FileWriter
	        FileWriter escritura = new FileWriter("C:/Users/ccast/Desktop/ficheroNuevo.txt");
	        for(int i = 0; i < frase.length(); i++) {
	            escritura.write(frase.charAt(i));
	        }
	        //Cerramos el stream
	        escritura.close();
	    } catch (IOException e) {
	    	//Imprime la pila de llamadas
	        e.printStackTrace();
	    }
	}
}
class Leer_Fichero{
	public void lee() {
		try {
			//Instance creation
			FileReader entrada=new FileReader("C:/Users/ccast/Desktop/ficheroNuevo.txt");
			int t=0;
			//While we haven't arrived until the end
			while(t!=-1) {
				t=entrada.read();
				//Transformamos los caracteres unicode con un casting
				char letter=(char)t;
				System.out.print(letter);
			}
			//Cerramos el flujo de datos
			entrada.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("No se ha encontrado el archivo");
		}
	}
}
class contarVocales{
	public void countVoc() {
		try {
			FileReader entrada=new FileReader("C:/Users/ccast/Desktop/ficheroNuevo.txt");
			int contador=0;
			int contador1=0;
			int consonante=0;
			String text="C:/Users/ccast/Desktop/ficheroNuevo.txt";
			for (int i=0; i<text.length();i++) {
				contador++;
			}
			for(int i=0;i<text.length();i++) {
				if((text.charAt(i)=='a')||(text.charAt(i)=='i')||(text.charAt(i)=='e')||(text.charAt(i)=='o')||(text.charAt(i)=='u')) {
					contador1++;
					
				}
			}
			consonante=contador-contador1;
			System.out.println("El texto contiene " + text + " contiene " + contador++ + " vocales");
			System.out.println("El texto contine " + text + " contiene " + consonante + " consonantes");
				}
			catch(IOException e) {
			System.out.println("No se encuentra el fichero");
			}
		
	}
}

