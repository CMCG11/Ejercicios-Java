package p2_t6;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;

public class OperacionesFicheros {
//1. Generamos el fichero Quijote.txt
public void escribir() {

	    String frase = "En un lugar de la Mancha, de cuyo nombre no quiero acordarme, no ha mucho tiempo que viv�a un hidalgo de los de lanza en astillero, adarga antigua, roc�n flaco y galgo corredor. Una olla de algo m�s vaca que carnero, salpic�n las m�s noches, duelos y quebrantos los s�bados, lentejas los viernes, alg�n palomino de a�adidura los domingos, consum�an las tres partes de su hacienda. El resto della conclu�an sayo de velarte, calzas de velludo para las fiestas con sus pantuflos de lo mismo, los d�as de entre semana se honraba con su vellori de lo m�s fino. Ten�a en su casa una ama que pasaba de los cuarenta, y una sobrina que no llegaba a los veinte, y un mozo de campo y plaza, que as� ensillaba el roc�n como tomaba la podadera. Frisaba la edad de nuestro hidalgo con los cincuenta a�os, era de complexi�n recia, seco de carnes, enjuto de rostro; gran madrugador y amigo de la caza. Quieren decir que ten�a el sobrenombre de Quijada o Quesada (que en esto hay alguna diferencia en los autores que deste caso escriben), aunque por conjeturas veros�miles se deja entender que se llama Quijana; pero esto importa poco a nuestro cuento; basta que en la narraci�n d�l no se salga un punto de la verdad";
	    try {
	    	//Utilizamos una instancia pertenceiente a la clase FileWriter
	        FileWriter escritura = new FileWriter("C:/Users/ccast/Desktop/Quijote.txt");
	        for(int i = 0; i < frase.length(); i++) {
	            escritura.write(frase.charAt(i));
	        }
	        //Cerramos el stream
	        escritura.close();
	    } catch (IOException e) {
	    	//Imprime la pila de llamadas
	        e.printStackTrace();
	    }
	}
//2.Leemos el fichero Caracter a caracter
public void leercaracteracaracter() {
		try {
			//Abrimos el fichero indicado
			FileReader entrada=new FileReader("C:/Users/ccast/Desktop/Quijote.txt");
			int caracter=0;
			//While we haven't arrived until the end
			while(caracter!=-1) {
				caracter=entrada.read();
				//Transformamos los caracteres unicode con un casting
				char letter=(char)caracter;
				System.out.print(letter);
		}
			//Cerramos el flujo de datos 
			entrada.close();
		}catch(FileNotFoundException e) {
			//Operaciones en caso de no encontrar el fichero 
			System.out.println("Error, no se ha encontrado el fichero");
			//Mostrar el error
			System.out.println(e.getMessage());
		}
		catch(Exception e) {
			//Operaciones de error general 
			System.out.println("Error de lectura del fichero");
			System.out.println(e.getMessage());
		}
		}
//2.1 Generamos el fichero QUijote_lineas.txt
public void GeneraFicheroQuijote (){
	try {
		FileReader entrada=new FileReader("C:/Users/ccast/Desktop/Quijote.txt");
		FileWriter entrada1=new FileWriter("C:/Users/ccast/Desktop/Quijote_lineas.txt");
		BufferedWriter escritura=new BufferedWriter(entrada1);
		int text=entrada.read();
		char character;
		String phrase="";
		//Leemos cada uno de los caracteres del fichero
		while (text!=-1) {
			character=(char)text;
		if (character == ','|| character == '.' || character ==';') {
			escritura.write(phrase);
			//Salto de linea
			escritura.newLine();
			//Refrescamos el buffer
			escritura.flush();
			//Limpiamos para empezar nueva frase
			phrase="";
		}
		else {
			phrase=phrase+character;
		}
		//leemos el siguiente caracter
		text=entrada.read();
		}
		//Cerramos el flujo de datos
		entrada.close();
		entrada1.close();
	}catch( IOException e) {
		System.out.println("Error no se ha encontrado el archivo");
		//Se muestra el error
		System.out.println(e.getMessage());
	}	
}//fin del metodo generar fichero
//3. Leer el fichero "Quijote_lineas.txt" y a sacarlo por pantalla.
public void Contenido () {
	try {
	String cadena="";
    FileReader f = new FileReader("C:/Users/ccast/Desktop/Quijote_lineas.txt");
    BufferedReader b = new BufferedReader(f);
    while((cadena = b.readLine())!=null) {
        System.out.println(cadena);
    }
    b.close();
	}catch(IOException e) {
		System.out.println("Error no se ha encontrada el archivo");
		//Se muestra el error
		System.out.println(e.getMessage());
		
	}
   
}//fin del metodo contenido
}




