package p2_t6;

public class Quijote {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Generamos el fichero txt que contiene el texto pedido 
		OperacionesFicheros x=new OperacionesFicheros();
		//LLamamos al metodo de generar el fichero
		x.escribir();
		//LLamamos al metodo de leer el fichero caracter a caracter
		x.leercaracteracaracter();
		//LLamamos al metodo escribe fichero para que genere el nuevo fichero Quijote_lineas.txt
		x.GeneraFicheroQuijote();
		//Llamamos al metodo de sacar el contenido por pantalla del fichero Quijote_lineas.txt
		x.Contenido();
	}

}
