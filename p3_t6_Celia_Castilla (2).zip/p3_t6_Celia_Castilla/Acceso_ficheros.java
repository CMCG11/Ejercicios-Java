package p3_t6;

import java.io.File;

public class Acceso_ficheros {
	public static void main(String[] args) {
	//4 BULLET EJERCICIO 3--Listar todos los ficheros y directorios que haya en la carpeta bin, del workspace en el que estamos-
	File ruta=new File("C:"+File.separator+"Users"+File.separator+"ccast"+File.separator+"eclipse-workspace"+File.separator+"Ficheros"+File.separator+"bin");
	System.out.println(ruta.getAbsolutePath());
	String [] nombre_archivos=ruta.list();
	for (int i=0;i<nombre_archivos.length;i++) {
		System.out.println(nombre_archivos[i]);
	//Creamos una nueva instancia
	File c=new File(ruta.getAbsolutePath(),nombre_archivos[i]);
	//Examina la ruta a cada vuelta de bucle
	//Comprobamos si son archivo o directorios
	if (c.isDirectory()) {
		String[] archivos_subfolder=c.list();
		for (int j=0;j<archivos_subfolder.length;j++) {
			System.out.println(archivos_subfolder[j]);
			
		}
	}
		
	}
}
}