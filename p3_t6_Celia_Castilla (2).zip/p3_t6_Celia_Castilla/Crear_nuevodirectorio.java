package p3_t6;

import java.io.File;

public class Crear_nuevodirectorio {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//EJERCICIO3 5 BULLET
		File ruta=new File("C:"+File.separator+"Users"+File.separator+"ccast"+File.separator+"eclipse-workspace"+File.separator+"Ficheros"+File.separator+"src"+File.separator+"p3_t6"+File.separator+"PruebaDirectorio");
		//Creamos el nuevo directorio
		ruta.mkdir();
		
	}

}
