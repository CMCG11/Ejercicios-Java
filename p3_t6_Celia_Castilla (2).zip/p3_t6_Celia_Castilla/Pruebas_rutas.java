package p3_t6;

import java.io.File;
public class Pruebas_rutas {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//EJERCICIO 3- 1 BULLET
		File entrada=new File("Ejercicio4_1.txt");
		//EJERCICIO 3 TERCER BULLET
		//Sacamos la ruta absoluta del archivo
		System.out.println(entrada.getAbsolutePath());
		//Miramos a ver si este archivo existe en la ruta especificada
		System.out.println(entrada.exists());
		

	}
}

