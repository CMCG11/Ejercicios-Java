package p3_t6;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class ejercicio1 {
	public static void main (String[]args) {
		Alumno a1=new Alumno("Miguel","Devesa",7);
		try {
			//serialize the object
			ObjectOutputStream writing_fichero=new ObjectOutputStream(new FileOutputStream("C:/Users/ccast/Desktop/java_pruebas/empleado.txt"));
			//write the object in the file
			writing_fichero.writeObject(a1);
			//close the flie
			writing_fichero.close();
			//end of serialization
			ObjectInputStream rescue_fichero=new ObjectInputStream(new FileInputStream("C:/Users/ccast/Desktop/java_pruebas/empleado.txt"));
			Alumno obj=(Alumno)rescue_fichero.readObject();
			System.out.println("Alumno:" +obj.getNombre() + "\nApellido:" +obj.getApellido() + "\nNotaMedia:" +obj.getNotamedia ());
			rescue_fichero.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}

}
//--------------------------------------------------------------------------------------------------
//Pick Alumno class from practice 1 topic 4
class Alumno implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2L;
		//Definimos las variables
		protected static String Nombre="";
		protected static String Apellido="";
		protected static int numalumnos=0;
		protected static int notamedia=0;
		//Creamos un constructor por defecto 
		public Alumno(String Nombre, String Apellidos, int notamedia) {
			this.Nombre=Nombre;
			this.Apellido=Apellido;
			this.notamedia=notamedia;
			
		}
			
		//Creamos el constructor copia
		public Alumno(Alumno a1) {
			this.Nombre=a1.getNombre();
			this.Apellido=a1.getApellido();
			this.numalumnos=a1.getNumalumnos();
			numalumnos++;

			
		}
		//Creaci�n de un constructor donde le pasamos como parametros los nombres y los apellidos
		public Alumno(String Nombre, String Apellido) {
			this.Nombre=Nombre;
			this.Apellido=Apellido;
			numalumnos++;
			
		}
		//Creamos el metodo numero de alumno
		public void contador() {
			System.out.println("El numero de alumnos es "+numalumnos);
		}
		
		//Creamos el metodo incrementar
		public static int incrementar() {
			notamedia++;
			return notamedia;
		}
		//Creamos el metodo resultado
		public void resultado() {
			//Lo llamo una vez con this y otra normal
			this.incrementar();
			incrementar();
			System.out.println("Nota Media es:"+notamedia);
		}
		//Generamos los getters y los setters de la clase alumno
		public static String getNombre() {
			return Nombre;
		}
		public static void setNombre(String nombre) {
			Nombre = nombre;
		}
		public static String getApellido() {
			return Apellido;
		}
		public static void setApellido(String apellido) {
			Apellido = apellido;
		}
		public static int getNumalumnos() {
			return numalumnos;
		}
		public static void setNumalumnos(int numalumnos) {
			Alumno.numalumnos = numalumnos;
		}
		public static int getNotamedia() {
			return notamedia;
		}
		public static void setNotamedia(int notamedia) {
			Alumno.notamedia = notamedia;
		}
		public String toString() {
			return "El Nombre es " +Nombre+ " y su apellido es " +Apellido+ " y el numero de alumnos es " +numalumnos;
		}
		}
