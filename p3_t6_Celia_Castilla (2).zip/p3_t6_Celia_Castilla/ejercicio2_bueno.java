package p3_t6;


import java.io.Serializable;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;

//Hay un error que no veo solo me coge el último alumno al recorrer el bucle. Adicionalmente he renombrado el array alumno como alumno 2 por que sino el programa no compilaba

public class ejercicio2_bueno {
	public static void main(String[]args) {
		Alumno2 []Clase=new Alumno2[5];
		Clase [0]= new Alumno2("Miguel","Devesa",10);
		Clase [1]=new Alumno2("Pedro","Martin",8);
		Clase [2]=new Alumno2("Charlenne", "Garcia",9);
		Clase [3]=new Alumno2("Ana","De la Fuente",10);
		Clase [4]=new Alumno2("Alvaro","Rivero",9);
		try {
			ObjectOutputStream escribiendo_fichero=new ObjectOutputStream(new FileOutputStream("C:/Users/ccast/Desktop/java_pruebas/alumno_b.txt"));
			escribiendo_fichero.writeObject(Clase);
			escribiendo_fichero.close();
			//Readobject
			ObjectInputStream rescue_fichero=new ObjectInputStream(new FileInputStream("C:/Users/ccast/Desktop/java_pruebas/alumno_b.txt"));
			Alumno2[]alumno_recuperado=(Alumno2[])rescue_fichero.readObject();
			rescue_fichero.close();
			for (Alumno2 e: alumno_recuperado) {
				System.out.println(e);
		}
		}catch(Exception e){
		
			}
		}
	}
//------------------------------------------------------------------------------
class Alumno2 implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected static String Nombre;
	protected static String Apellido;
	protected static  int notamedia;
	
	public Alumno2(String Nombre, String Apellido , int notamedia) {
		this.Nombre=Nombre;
		this.Apellido=Apellido;
		this.notamedia=notamedia;
	}
	//Getters & Setters
	public String getNombre() {
		return Nombre;
	}
	public String getApellido() {
		return Apellido;
	}
	public void setApellido(String apellido) {
		Apellido = apellido;
	}

	public int getNotamedia() {
		return notamedia;
	}
	public void setNotamedia(int notamedia) {
		this.notamedia = notamedia;
	}
	public void setNombre(String nombre) {
		Nombre = nombre;
	}
	public String toString() {
		return "El Nombre es " +Nombre+ " y su apellido es " +Apellido+ " y la nota media es " +notamedia;
	}
	
}